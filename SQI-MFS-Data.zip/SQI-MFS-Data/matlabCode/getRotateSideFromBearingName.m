function [output] = getRotateSideFromBearingName(bearingName)

switch bearingName
    case 'bearing1'
        output = 'inner';
    case 'bearing2'
        output = 'inner';
    case 'bearing3'
        output = '';
    case 'bearing4'
        output = 'inner';
    case 'bearing5'
        output = 'inner';
    case 'bearing6'
        output = 'inner';
    case 'bearing7'
        output = 'inner';
    case 'bearing8'
        output = 'inner';
    case 'bearing9'
        output = 'inner';
    case 'bearing10'
        output = 'outer';
    case 'bearing11'
        output = 'outer';
    case 'bearing12'
        output = 'outer';
    case 'bearing13'
        output = 'outer';
    case 'bearing14'
        output = 'outer';
    case 'bearing15'
        output = 'outer';
    case 'bearing16'
        output = 'outer';
    case 'bearing17'
        output = 'outer';
    case 'bearing18'
        output = 'outer';
    case 'bearing19'
        output = 'inner';
    case 'bearing20'
        output = 'outer';
    otherwise
        output = '';
end

