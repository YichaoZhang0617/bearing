clc;
clear;
load('SQIMFS.mat');
load('SQI_075inch_ThreeLoad.mat');

% sampleRate = 10000;
sampleRate = 25600;

data = Three075Health20Hz(:,4);
daqName = '75health20Hz';

% data = combine;
% daqName = '75combine15Hz';

titleName = 'test';

output_args = plotAverageFFT(data, sampleRate, 102400, 4, titleName);



