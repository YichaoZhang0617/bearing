function [ratio] = getRatioFromBearing( bearingType ,rotateSide, faultType)

%��strcmp���Ƚ������ַ���
if strcmp(bearingType, 'BS2-2210-2RS-VT143') 
    switch faultType
        case 'cageFault'
            %�������Ȧ�̶�����Ȧ��תʱ�����ּܹ���Ƶ��Ϊ0.429X
            if strcmp(rotateSide, 'inner')
                ratio = 0.429;
            %�������Ȧ�̶�����Ȧ��תʱ�����ּܹ���Ƶ��Ϊ0.571X
            elseif strcmp(rotateSide, 'outer')
                ratio = 0.571;
            end
        case 'ballFault'
            ratio = 3.42;
        case 'innerFault'
            ratio = 10.85;
        case 'outerFault'
            ratio = 8.15;
        case 'innerRunOff'
            ratio = 3;
        case 'outerRunOff'
            ratio = 4;
        otherwise
            ratio = 0;
    end
end


if strcmp(bearingType, 'BS2-2215-2RS-VT143')
    switch faultType
        case 'cageFault'
            if strcmp(rotateSide, 'inner')
                ratio = 0.431;
            elseif strcmp(rotateSide, 'outer')
                ratio = 0.569;
            end
        case 'ballFault'
            ratio = 3.51;
        case 'innerFault'
            ratio = 11.95;
        case 'outerFault'
            ratio = 9.05;
        case 'innerRunOff'
            ratio = 3;
        case 'outerRunOff'
            ratio = 4;
        otherwise
            ratio = 0;
    end
end


if strcmp(bearingType, '75inchRotorBearing')
    switch faultType
        case 'cageFault'
            ratio = 0.378;
        case 'ballFault'
            ratio = 1.992*2;
        case 'innerFault'
            ratio = 4.95;
        case 'outerFault'
            ratio = 3.048;
        case 'innerRunOff'
            ratio = 3;
        case 'outerRunOff'
            ratio = 4;
        otherwise
            ratio = 0;
    end
end

end