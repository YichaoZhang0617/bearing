clc;
clear;
load('SQIMFS.mat');
load('SQI_075inch_ThreeLoad.mat');

sampleRate = 10000;
% sampleRate2 = 25600;

data = Three075Ball20Hz(:,4);
daqName = '75Ball20Hz';

% data = health;
% daqName = '75health15Hz';

fc = 300;
rotateFrequency = [15,16];
filted_data = butterFilter(data,sampleRate,fc,4);   %300Hz��ͨ�˲���4�׹��ˣ�ע��butterFilter���Զ��庯��

% %origin data stem
% subplot(4,4,1);
% stem(data);
% title([daqName,'-origin']);
% xlabel('time/s');
% ylabel('amplitude');
% 
% %rms data stem
% subplot(4,4,2);
% rms_c( data, sampleRate/100, [daqName,'-rms'] ); %rms�������趨Ϊ10ms
% 
% %fft data stem
% subplot(4,4,3);
% fftData = fft_c(data, sampleRate, [daqName,'-fft']);
% 
% %filted-data-fft
% subplot(4,4,4);
% fldFFTData = fft_c(filted_data, sampleRate, [daqName,'-filtedFFT']);
% axis([0,fc,0,inf]);
% 
% %filted-origin stem
% subplot(4,4,5);
% stem(filted_data);
% title([daqName,'-filtedOrigin']);
% xlabel('time/s');
% ylabel('amplitude')
% 
% %filted-rms stem
% subplot(4,4,6);
% rmsData = rms_c( filted_data, sampleRate/100, [daqName,'-filtedRMS'] ); %rms�������趨Ϊ10ms
% 
% %fft-rotated stem
% subplot(4,4,7);
% plotFFTFromRange(filted_data, sampleRate, rotateFrequency, [daqName,'-fftRotate'])
% 
% %fft-2rotated stem
% subplot(4,4,8);
% range = 2*rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, range, [daqName,'-fft2Rotate'])
% 
% %fft-ftf stem
% subplot(4,4,9);
% ftf = getRatioFromBearing( '75inchRotorBearing' ,'inner', 'cageFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, ftf, [daqName,'-FTF']);
% 
% %fft-ftf2 stem
% subplot(4,4,10);
% ftf2 = 2 * getRatioFromBearing( '75inchRotorBearing' ,'inner', 'cageFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, ftf2, [daqName,'-FTF2']);
% 
% %fft-bpfo stem
% subplot(4,4,11);
% bpfo = getRatioFromBearing( '75inchRotorBearing' ,'inner', 'outerFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bpfo, [daqName,'-bpfo']);
% % plotAverageFFTFromRange(filted_data, sampleRate, 800000, 5, bpfo, [daqName,'-bpfo'])
% 
% %fft-bpfo2 stem
% subplot(4,4,12);
% bpfo2 = 2 * getRatioFromBearing( '75inchRotorBearing' ,'inner', 'outerFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bpfo2, [daqName,'-bpfo2']);
% % plotAverageFFTFromRange(filted_data, sampleRate, 800000, 5, bpfo2, [daqName,'-bpfo2'])
% 
% 
% %fft-bpfi stem
% subplot(4,4,13);
% bpfi = getRatioFromBearing( '75inchRotorBearing' ,'inner', 'innerFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bpfi, [daqName,'-bpfi']);
% 
% %fft-bpfi2 stem
% subplot(4,4,14);
% bpfi2 = 2 * getRatioFromBearing( '75inchRotorBearing' ,'inner', 'innerFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bpfi2, [daqName,'-bpfi2']);
% 
% %fft-bsf stem
% subplot(4,4,15);
% bsf = getRatioFromBearing( '75inchRotorBearing' ,'inner', 'ballFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bsf, [daqName,'-bsf']);
% 
% %fft-bsf2 stem
% subplot(4,4,16);
% bsf2 = 2 * getRatioFromBearing( '75inchRotorBearing' ,'inner', 'ballFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bsf2, [daqName,'-bsf2']);


%%  average FFT
sampleSize = 51200;
sampleNumber = 5;

figure;
%origin data stem
subplot(4,4,1);
stem(data);
title([daqName,'-origin']);
xlabel('time/s');
ylabel('amplitude');

%rms data stem
subplot(4,4,2);
rms_c( data, sampleRate/100, [daqName,'-rms'] ); %rms�������趨Ϊ10ms��Ҳ����ÿ100�����ݼ���һ��rmsֵ
%rms_c���Զ��庯��

%fft data stem
subplot(4,4,3);
% fftData = fft_c(data, sampleRate, [daqName,'-fft']);
plotAverageFFT(data, sampleRate, sampleSize, sampleNumber, [daqName,'-fft']);

%filted-data-fft
subplot(4,4,4);
% fldFFTData = fft_c(filted_data, sampleRate, [daqName,'-filtedFFT']);
plotAverageFFT(filted_data, sampleRate, sampleSize, sampleNumber,  [daqName,'-filtedFFT']);
axis([0,fc,0,inf]);

%filted-origin stem
subplot(4,4,5);
stem(filted_data);
title([daqName,'-filtedOrigin']);
xlabel('time/s');
ylabel('amplitude')

%filted-rms stem
subplot(4,4,6);
rmsData = rms_c( filted_data, sampleRate/100, [daqName,'-filtedRMS'] ); %rms�������趨Ϊ10ms

%fft-rotated stem
subplot(4,4,7);
% plotFFTFromRange(filted_data, sampleRate, rotateFrequency, [daqName,'-fftRotate'])
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, rotateFrequency, [daqName,'-fftRotate']);

%fft-2rotated stem
subplot(4,4,8);
range = 2*rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, range, [daqName,'-fft2Rotate'])
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, range, [daqName,'-fft2Rotate']);

%fft-ftf stem
subplot(4,4,9);
ftf = getRatioFromBearing( '75inchRotorBearing' ,'inner', 'cageFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, ftf, [daqName,'-FTF']);
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, ftf, [daqName,'-FTF']);

%fft-ftf2 stem
subplot(4,4,10);
ftf2 = 2 * getRatioFromBearing( '75inchRotorBearing' ,'inner', 'cageFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, ftf2, [daqName,'-FTF2']);
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, ftf2, [daqName,'-FTF2']);

%fft-bpfo stem
subplot(4,4,11);
bpfo = getRatioFromBearing( '75inchRotorBearing' ,'inner', 'outerFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bpfo, [daqName,'-bpfo']);
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, bpfo, [daqName,'-bpfo']);

%fft-bpfo2 stem
subplot(4,4,12);
bpfo2 = 2 * getRatioFromBearing( '75inchRotorBearing' ,'inner', 'outerFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bpfo2, [daqName,'-bpfo2']);
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, bpfo2, [daqName,'-bpfo2']);


%fft-bpfi stem
subplot(4,4,13);
bpfi = getRatioFromBearing( '75inchRotorBearing' ,'inner', 'innerFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bpfi, [daqName,'-bpfi']);
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, bpfi, [daqName,'-bpfi']);

%fft-bpfi2 stem
subplot(4,4,14);
bpfi2 = 2 * getRatioFromBearing( '75inchRotorBearing' ,'inner', 'innerFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bpfi2, [daqName,'-bpfi2']);
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, bpfi2, [daqName,'-bpfi2']);

%fft-bsf stem
subplot(4,4,15);
bsf = getRatioFromBearing( '75inchRotorBearing' ,'inner', 'ballFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bsf, [daqName,'-bsf']);
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, bsf, [daqName,'-bsf']);

%fft-bsf2 stem
subplot(4,4,16);
bsf2 = 2 * getRatioFromBearing( '75inchRotorBearing' ,'inner', 'ballFault') * rotateFrequency;
% plotFFTFromRange(filted_data, sampleRate, bsf2, [daqName,'-bsf2']);
plotAverageFFTFromRange(filted_data, sampleRate, sampleSize, sampleNumber, bsf2,  [daqName,'-bsf2']);



