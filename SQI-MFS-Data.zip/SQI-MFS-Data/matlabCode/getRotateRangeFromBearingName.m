function [outputRange] = getRotateRangeFromBearingName(bearingName)

switch bearingName
    case 'bearing1'
        outputRange = [12,13];
    case 'bearing2'
        outputRange = [12,13];
    case 'bearing3'
        outputRange = [12,13];
    case 'bearing4'
        outputRange = [12,13];
    case 'bearing5'
        outputRange = [12,13];
    case 'bearing6'
        outputRange = [12,13];
    case 'bearing7'
        outputRange = [9,10];
    case 'bearing8'
        outputRange = [9,10];
    case 'bearing9'
        outputRange = [10,11];
    case 'bearing10'
        outputRange = [9,10];
    case 'bearing11'
        outputRange = [7,8];
    case 'bearing12'
        outputRange = [7,8];
    case 'bearing13'
        outputRange = [7,9];
    case 'bearing14'
        outputRange = [7,9];
    case 'bearing15'
        outputRange = [8,10];
    case 'bearing16'
        outputRange = [8,10];
    case 'bearing17'
        outputRange = [14,15];
    case 'bearing18'
        outputRange = [14,15];
    case 'bearing19'
        outputRange = [12,13];
    case 'bearing20'
        outputRange = [8,10];
    otherwise
        outputRange = [0,0];
end







end
