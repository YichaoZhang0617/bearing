function [output] = getTypeFromBearingName(bearingName)

switch bearingName
    case 'bearing1'
        output =  'BS2-2210-2RS-VT143';
    case 'bearing2'
        output =  'BS2-2210-2RS-VT143';
    case 'bearing3'
        output = '';
    case 'bearing4'
        output =  'BS2-2210-2RS-VT143';
    case 'bearing5'
        output = 'BS2-2215-2RS-VT143';
    case 'bearing6'
        output = 'BS2-2210-2RS-VT143';
    case 'bearing7'
        output = 'BS2-2210-2RS-VT143';
    case 'bearing8'
        output = 'BS2-2210-2RS-VT143';
    case 'bearing9'
        output = 'BS2-2210-2RS-VT143';
    case 'bearing10'
        output = '';
    case 'bearing11'
        output = '';
    case 'bearing12'
        output = '';
    case 'bearing13'
        output = 'BS2-2210-2RS-VT143';
    case 'bearing14'
        output = 'BS2-2210-2RS-VT143';
    case 'bearing15'
        output = 'BS2-2210-2RS-VT143';
    case 'bearing16'
        output = 'BS2-2210-2RS-VT143';
    case 'bearing17'
        output = '';
    case 'bearing18'
        output = '';
    case 'bearing19'
        output = 'BS2-2215-2RS-VT143';
    case 'bearing20'
        output = '';
    otherwise
        output = '';
end


end
