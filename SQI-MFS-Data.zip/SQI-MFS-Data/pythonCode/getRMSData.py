#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

import math
# 将原始数据分为多份，每份interval，然后求各份的RMS值
def getRMSData(data,interval):
    # 按间隔求RMS
    size = len(data) / interval
    # 读取前面的整数组,这里是小数位自动进1的
    bathsize = math.ceil(size)
    RMS = []
    for i in range(1,bathsize):
        start = interval * (i - 1)
        count = 0
        for j in range(start,start + interval):
            square = data[j] * data[j]
            count = count + square
        RMS.append(math.sqrt(count / interval))
    return RMS

