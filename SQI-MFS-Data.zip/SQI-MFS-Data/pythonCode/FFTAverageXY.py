#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from scipy.fftpack import fft
import numpy as np

# data 表示原始数据 ,sampleRate 表示采样率 ,averageSize 表示一组的数据点数 ,averageNumber 表示组数

def FFTAverageXY(data,sampleRate,averageSize,averageNumber):
    # A、对分组后的各个组求FFT变换之后的平均值
    # count 表示最后求和后的数组，并不是单纯的求和，而是傅里叶变换同一位置数相加
    count = [0] * averageSize
    # averageSize 指分组的个数
    i = 1
    while i < averageNumber:
        start = (i - 1) * averageSize
        end = start + averageSize
        group = data[start:end]
        # group 表示每一小组的平均数,也就是averageSize=800000
        N = len(group)

        x = group
        # 对数据进行傅里叶变换
        y = fft(x, N)
        # 求得傅里叶变换后的振幅
        mag = abs(y)
        k = 0
        for j in mag:
            if k < averageSize:
                count[k] = j + count[k]
                k = k + 1
        i = i + 1
    # 其中average表示幅值的平均值
    average = [x / 5 for x in count]
    yy = np.array(average)

    # B、获取频率序列
    # 表示数据点数800000
    N = averageSize
    # 获取频率序列
    f = []
    for i in range(N):
        ff = i * sampleRate / N
        f.append(ff)

    # 将list转换为ndarray类型
    xx = np.array(f)
    return xx ,yy