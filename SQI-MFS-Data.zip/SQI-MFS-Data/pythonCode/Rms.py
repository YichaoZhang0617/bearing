#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

# 求原始振动数据的RMS值
import math
# count 表示原始振动数据平方之和
def Rms(data):
    # N 表示数据的长度
    N = len(data)
    count = 0
    for i in range(N):
        square = data[i] + data[i]
        count = count + square
    # count 表示原始振动数据平方之和
    rms = math.sqrt(count / N)
    return rms