#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao


from scipy.fftpack import fft
import matplotlib.pyplot as plt
import numpy as np

def plotFFTAveragefromRange(data, sampleRate ,averageSize ,avergernumber,typerange, titlename):
    # 一、对分组后的各个组求FFT变换之后的平均值
    # count 表示最后求和后的数组
    count = [0] * averageSize
    # averageSize 指分组的个数
    i = 1
    while i < avergernumber:
        start = (i - 1) * averageSize
        end = start + averageSize
        group = data[start:end]
        # group 表示每一小组的平均数
        N = len(group)

        x = group
        # 对数据进行傅里叶变换
        y = fft(x, N)
        # 求得傅里叶变换后的振幅
        mag = abs(y)
        k = 0
        for j in mag:
            if k < averageSize:
                count[k] = j + count[k]
                k = k + 1
        i = i + 1
    # 其中averger表示幅值的平均值
    averger = [x / 5 for x in count]
    yy = np.array(averger)

    # 二、获取频率序列
    # 表示数据点数
    N = averageSize
    # 获取频率序列
    f = []
    for i in range(N):
        ff = i * sampleRate / N
        f.append(ff)

    # 将list转换为ndarray类型
    xx = np.array(f)

    fig = plt.figure()

    # 一、保持架区间段
    # 选择区间的起始位置
    start = int(typerange[0][0] / (sampleRate / N))
    end = int(typerange[0][1] / (sampleRate / N)) + 1

    x2 = xx[start:end + 1]
    y2 = yy[start:end + 1]
    fig.add_subplot(221)
    plt.plot(x2, y2)
    plt.title(titlename[0])


    # 二、外圈区间段
    # 选择区间的起始位置
    start = int(typerange[1][0] / (sampleRate / N))
    end = int(typerange[1][1] / (sampleRate / N)) + 1

    x2 = xx[start:end + 1]
    y2 = yy[start:end + 1]
    fig.add_subplot(222)
    plt.plot(x2, y2)
    plt.title(titlename[1])


    # 三、内圈区间段
    # 选择区间的起始位置
    start = int(typerange[2][0] / (sampleRate / N))
    end = int(typerange[2][1] / (sampleRate / N)) + 1

    x2 = xx[start:end + 1]
    y2 = yy[start:end + 1]
    fig.add_subplot(223)
    plt.plot(x2, y2)
    plt.title(titlename[2])

    # 四、故障区间段
    # 选择区间的起始位置
    start = int(typerange[3][0] / (sampleRate / N))
    end = int(typerange[3][1] / (sampleRate / N)) + 1

    x2 = xx[start:end + 1]
    y2 = yy[start:end + 1]
    fig.add_subplot(224)
    plt.plot(x2, y2)
    plt.title(titlename[3])

    plt.show()