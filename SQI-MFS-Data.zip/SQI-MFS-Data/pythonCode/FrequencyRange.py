#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

# 找出xx属于sf频率段时yy的取值范围
import numpy as np
def FrequencyRange(xx,yy,sf):

    posmin = np.argwhere(xx >= sf[0])
    a = min(posmin)
    # a 为ndarray类型，转为int型才能作为索引下标
    a = int(a)

    posmax = np.argwhere(xx <= sf[1])
    b = max(posmax)
    # b 为ndarray类型，转为int型才能作为索引下标
    b = int(b)

    # 其中rangeFFT表示属于区间sf时的幅值取值范围
    rangeFFT = yy[a:b]
    return  rangeFFT