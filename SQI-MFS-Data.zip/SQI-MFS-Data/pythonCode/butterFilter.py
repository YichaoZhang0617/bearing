#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from scipy import signal
def butterFilter(data,sampleRate,fc,filterType,n):
    Fs = sampleRate
    # 截止频率 = 频率(Hz)/奈奎斯特频率（采样率*0.5）
    Wc = 2 * fc / Fs   # 截止频率
    b,a = signal.butter(n,Wc,filterType)   # n阶低通滤波
    Signal_Filter = signal.filtfilt(b , a ,data)
    return  Signal_Filter


