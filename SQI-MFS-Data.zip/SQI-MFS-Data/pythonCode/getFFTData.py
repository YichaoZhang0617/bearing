#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from scipy.fftpack import fft,ifft
import numpy as np
# 对原始数据进行FFT变换后得到幅值和频域
def getFFTData(data,sampleRate):
    # 采样频率
    fs = sampleRate
    N = len(data)
    # 对数据进行傅里叶变换
    y = fft(data)
    # 求得傅里叶变换后的振幅
    mag = abs(y)

    # 频域序列
    fftrms = []
    for k in range(N):
        ff = k * fs / N
        fftrms.append(ff)

    xx = np.array(fftrms)
    yy = np.array(mag)

    # 注意顺序，返回幅值和频率
    return yy,xx

