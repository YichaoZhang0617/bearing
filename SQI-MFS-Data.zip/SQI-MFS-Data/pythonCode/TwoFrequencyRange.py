#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

# 由一倍频区间确定二倍频区间
def TwoFrequencyRange(range):
    # 求二倍sf频区间
    start = (range[0]) * 2
    end = (range[1]) * 2
    Interval= [start, end]
    return Interval