#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from matplotlib import pyplot as plt

# 获取震荡频率的x,y坐标
def plotData(data,title):
    # xlabel 表示绘图后的横坐标，数据点数就是长度
    xlabel = []
    x_values = len(data)
    for i in range(1, x_values + 1):
        xlabel.append(i)
    # ylabel 表示绘图后的纵坐标，原始震荡值就是y轴坐标值
    ylabel = data
    plt.plot(xlabel, ylabel)
    plt.title(title)

