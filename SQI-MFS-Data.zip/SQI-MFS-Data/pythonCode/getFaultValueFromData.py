#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from bearingGroup import Inch075MFSBearing
from Rms import Rms
from FFTRms import  FFTRms
from FFTXY import FFTXY
from FFTAverageXY import FFTAverageXY
from FrequencyRange import FrequencyRange
from TwoFrequencyRange import TwoFrequencyRange
from butterFilter import butterFilter


def getFaultValueFromData(data,configFile):

    # 先判断是否进行滤波，原始数据data，不管是否滤波之后仍是data
    sampleRate = configFile['sampleRate']  # sampleRate 采样率 是 int 类型
    ifFilter = configFile['ifFilter']   # 是否过滤
    if ifFilter == 'true':
        filterType = configFile['filterType']  # 过滤的滤波类型   高通、低通还是带通
        filterFreq = configFile['filterFreq']  # 滤波频率
        data= butterFilter(data, sampleRate, filterFreq, filterType, 4)  # 这里的data是滤波后的数据
    else:
        data = data

    sf = configFile['sf']    # 确定sf区间
    classtype = configFile['type']     # classtype 是类名
    if classtype == 'Inch075MFSBearing':
        # 由sf区间获取四种频段的区间
        Bearing = Inch075MFSBearing()
        # ftf, bpfo, bpfi, bsf 是 list的数组
        ftf, bpfo, bpfi, bsf = Bearing.Interval_section(sf[0], sf[1])

    # 一、求原始数据的rms
    rms = Rms(data)
    print("rms值为" + str(rms))

    # 二、求经FFT变换后的rms
    fftrms = FFTRms(data)
    print("fftrms值为" + str(fftrms))

    valueMonitor = configFile['valueMonitor']  # valueMonitor 是 str 类型 ，确定求 区间内的max还是rms

    # 各个区间的名称
    title = ['sf区间段', 'sf二倍频区间段', 'ftf区间段', 'ftf二频段区间段', 'bsf区间段', 'bsf二频段区间段', 'bpfi区间段', 'bpfi二频段区间段', 'bpfo区间段', 'bpfo二频段区间段']

    # 判断是否取平均值
    ifAverage = configFile['ifAverage']
    if ifAverage == 'false':

        # 如果不取平均值，对原始数据进行处理
        # 三、返回sf值

        # 求傅里叶变换之后的XY轴数据
        xx ,yy = FFTXY(data,sampleRate)
        # 找出xx属于sf的区间段时yy的取值范围
        rangeFFT = FrequencyRange(xx,yy,sf)
        # 用eval函数判断取最大值或RMS值并实现输出
        sf1 = eval((valueMonitor + '(rangeFFT)'))
        print( title[0] + '的' + str(valueMonitor) + '为' + str(sf1))

        # 四、返回sf2值
        # 确定二倍频区间
        sf2 = TwoFrequencyRange(sf)
        # 找出xx属于sf * 2的区间段时yy的取值范围
        rangeFFT2 = FrequencyRange(xx, yy, sf2)
        # 用eval函数判断取最大值或RMS值并实现输出
        sf2 = eval((valueMonitor + '(rangeFFT2)'))
        print(title[1] + '的' + str(valueMonitor) + '为' + str(sf2))

        # 五、返回ftf值
        # 找出xx属于保持架的区间段时yy的取值范围
        rangeFFT = FrequencyRange(xx, yy, ftf)
        # 用eval函数判断取最大值或RMS值并实现输出
        ftf1 = eval((valueMonitor + '(rangeFFT)'))
        print( title[2] + '的' + str(valueMonitor) + '为' + str(ftf1))

        # 六、返回ftf2值
        # 确定二倍频区间
        ftf2 = TwoFrequencyRange(ftf)
        # 找出xx属于二倍保持架区间段时yy的取值范围
        rangeFFT2 = FrequencyRange(xx, yy, ftf2)
        # 用eval函数判断取最大值或RMS值并实现输出
        ftf2 = eval((valueMonitor + '(rangeFFT2)'))
        print(title[3] + '的' + str(valueMonitor) + '为' + str(ftf2))

        # 七、返回bsf
        # 找出xx属于滚动体故障区间段时yy的取值范围
        rangeFFT = FrequencyRange(xx, yy, bsf)
        # 用eval函数判断取最大值或RMS值并实现输出
        bsf1 = eval((valueMonitor + '(rangeFFT)'))
        print(title[4] + '的' + str(valueMonitor) + '为' + str(bsf1))

        # 八、返回bsf2值
        # 确定二倍频区间
        bsf2 = TwoFrequencyRange(bsf)
        # 找出xx属于二倍频滚动体故障区间段时yy的取值范围
        rangeFFT2 = FrequencyRange(xx, yy, bsf2)
        # 用eval函数判断取最大值或RMS值并实现输出
        bsf2 = eval((valueMonitor + '(rangeFFT2)'))
        print(title[5] + '的' + str(valueMonitor) + '为' + str(bsf2))

        # 九、返回bpfi
        # 找出xx属于内圈故障区间段时yy的取值范围
        rangeFFT = FrequencyRange(xx, yy, bpfi)
        # 用eval函数判断取最大值或RMS值并实现输出
        bpfi1 = eval((valueMonitor + '(rangeFFT)'))
        print(title[6] + '的' + str(valueMonitor) + '为' + str(bpfi1))

        # 十、返回bpfi2值
        # 确定二倍频区间
        bpfi2 = TwoFrequencyRange(bpfi)
        # 找出xx属于二倍频内圈故障区间段时yy的取值范围
        rangeFFT2 = FrequencyRange(xx, yy, bpfi2)
        # 用eval函数判断取最大值或RMS值并实现输出
        bpfi2 = eval((valueMonitor + '(rangeFFT2)'))
        print(title[7] + '的' + str(valueMonitor) + '为' + str(bpfi2))

        # 十一、返回bpfo
        rangeFFT = FrequencyRange(xx, yy, bpfo)
        # 用eval函数判断取最大值或RMS值并实现输出
        bpfo1 = eval((valueMonitor + '(rangeFFT)'))
        print(title[8] + '的' + str(valueMonitor) + '为' + str(bpfo1))

        # 十二、返回bpfo2值
        # 确定二倍频区间
        bpfo2 = TwoFrequencyRange(bpfo)
        rangeFFT2 = FrequencyRange(xx, yy, bpfo2)
        # 用eval函数判断取最大值或RMS值并实现输出
        bpfo2 = eval((valueMonitor + '(rangeFFT2)'))
        print(title[9] + '的' + str(valueMonitor) + '为' + str(bpfo2))
    else:
        # 如果取平均值，对数据进行分批处理，然后对每批数据处理后取平均值
        averageSize = configFile['averageSize']  # averageSize 表示每批数据的数据点数
        averageNumber = configFile['averageNumber']  # averageNumber 表示分为多少组
        # 准备工作：
        # A、对分组后的各个组求FFT变换之后的平均值
        # B、获取频率序列

        # 将原始数据分为5组，然后取傅里叶变换，对五组幅值之和取平均值后对应的XY轴数据
        xx, yy = FFTAverageXY(data,sampleRate,averageSize,averageNumber)


        # 三、返回sf值
        # 找出xx属于sf的区间段时yy的取值范围
        rangeFFT = FrequencyRange(xx, yy, sf)
        # 用eval函数判断取最大值或RMS值并实现输出
        sf1 = eval((valueMonitor + '(rangeFFT)'))
        print('取平均值后'+ title[0] + '的' + str(valueMonitor) + '为' + str(sf1))

        # 四、返回sf2值
        # 确定二倍频区间
        sf2 = TwoFrequencyRange(sf)
        # 找出xx属于sf * 2的区间段时yy的取值范围
        rangeFFT2 = FrequencyRange(xx, yy, sf2)
        # 用eval函数判断取最大值或RMS值并实现输出
        sf2 = eval((valueMonitor + '(rangeFFT2)'))
        print('取平均值后' + title[1] + '的' + str(valueMonitor) + '为' + str(sf2))

        # 五、返回ftf值
        # 找出xx属于保持架的区间段时yy的取值范围
        rangeFFT = FrequencyRange(xx, yy, ftf)
        # 用eval函数判断取最大值或RMS值并实现输出
        ftf1 = eval((valueMonitor + '(rangeFFT)'))
        print('取平均值后' + title[2] + '的' + str(valueMonitor) + '为' + str(ftf1))

        # 六、返回ftf2值
        # 确定二倍频区间
        ftf2 = TwoFrequencyRange(ftf)
        # 找出xx属于二倍保持架区间段时yy的取值范围
        rangeFFT2 = FrequencyRange(xx, yy, ftf2)
        # 用eval函数判断取最大值或RMS值并实现输出
        ftf2 = eval((valueMonitor + '(rangeFFT2)'))
        print('取平均值后' + title[3] + '的' + str(valueMonitor) + '为' + str(ftf2))

        # 七、返回bsf
        # 找出xx属于滚动体故障区间段时yy的取值范围
        rangeFFT = FrequencyRange(xx, yy, bsf)
        # 用eval函数判断取最大值或RMS值并实现输出
        bsf1 = eval((valueMonitor + '(rangeFFT)'))
        print('取平均值后' + title[4] + '的' + str(valueMonitor) + '为' + str(bsf1))

        # 八、返回bsf2值
        # 确定二倍频区间
        bsf2 = TwoFrequencyRange(bsf)
        # 找出xx属于二倍频滚动体故障区间段时yy的取值范围
        rangeFFT2 = FrequencyRange(xx, yy, bsf2)
        # 用eval函数判断取最大值或RMS值并实现输出
        bsf2 = eval((valueMonitor + '(rangeFFT2)'))
        print('取平均值后' + title[5] + '的' + str(valueMonitor) + '为' + str(bsf2))

        # 九、返回bpfi
        # 找出xx属于内圈故障区间段时yy的取值范围
        rangeFFT = FrequencyRange(xx, yy, bpfi)
        # 用eval函数判断取最大值或RMS值并实现输出
        bpfi1 = eval((valueMonitor + '(rangeFFT)'))
        print('取平均值后' + title[6] + '的' + str(valueMonitor) + '为' + str(bpfi1))

        # 十、返回bpfi2值
        # 确定二倍频区间
        bpfi2 = TwoFrequencyRange(bpfi)
        # 找出xx属于二倍频内圈故障区间段时yy的取值范围
        rangeFFT2 = FrequencyRange(xx, yy, bpfi2)
        # 用eval函数判断取最大值或RMS值并实现输出
        bpfi2 = eval((valueMonitor + '(rangeFFT2)'))
        print('取平均值后' + title[7] + '的' + str(valueMonitor) + '为' + str(bpfi2))

        # 十一、返回bpfo
        rangeFFT = FrequencyRange(xx, yy, bpfo)
        # 用eval函数判断取最大值或RMS值并实现输出
        bpfo1 = eval((valueMonitor + '(rangeFFT)'))
        print('取平均值后' + title[8] + '的' + str(valueMonitor) + '为' + str(bpfo1))

        # 十二、返回bpfo2值
        # 确定二倍频区间
        bpfo2 = TwoFrequencyRange(bpfo)
        rangeFFT2 = FrequencyRange(xx, yy, bpfo2)
        # 用eval函数判断取最大值或RMS值并实现输出
        bpfo2 = eval((valueMonitor + '(rangeFFT2)'))
        print('取平均值后' + title[9] + '的' + str(valueMonitor) + '为' + str(bpfo2))


    return rms,fftrms,sf1,sf2,ftf1,ftf2,bsf1,bsf2,bpfi1,bpfi2,bpfo1,bpfo2