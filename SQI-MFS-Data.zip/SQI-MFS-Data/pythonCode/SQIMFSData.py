#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao
from matplotlib import pyplot as plt
import json

from Readdata import Readdata
from getFFTData import  getFFTData
from plotData import  plotData
from getRMSData import  getRMSData
from plotFFTData import plotFFTData
from plotFFTfromRange import plotFFTfromRange
from plotFFTAverage import plotFFTAverage
from plotFFTAveragefromRange import plotFFTAveragefromRange
from getFaultValueFromData import getFaultValueFromData
from bearingGroup import Inch075MFSBearing

# 打开相关文件
health  = open('health15Hz.txt', 'r')
outer   = open('outer15Hz.txt', 'r')
inner   = open('inner15Hz.txt', 'r')
ball    = open('ball15Hz.txt', 'r')
combine = open('combine15Hz.txt', 'r')

# 打开json配置文件
with open("configFile.json",'r') as load_f:
    load_dict = json.load(load_f)

# 读取原始震荡数据
healthdata = Readdata(health)
outerdata = Readdata(outer)
innerdata = Readdata(inner)
balldata = Readdata(ball)
combinedata = Readdata(combine)

getFaultValueFromData(healthdata,load_dict)
getFaultValueFromData(outerdata,load_dict)
getFaultValueFromData(innerdata,load_dict)
getFaultValueFromData(balldata,load_dict)
getFaultValueFromData(combinedata,load_dict)

# 获取时域的震荡值，并绘制图形
plt.subplot(4,4,1)
plotData(healthdata,'healthRow')
plt.subplot(4,4,2)
plotData(innerdata,'innerRow')
plt.subplot(4,4,3)
plotData(balldata,'ballRow')
plt.subplot(4,4,4)
plotData(outerdata,'outerRow')
plt.subplot(4,4,5)
plotData(combinedata,'combineRow')

# 求时域的RMS值，分组求RMS，每组sampleRate个数据点数
sampleRate = load_dict['sampleRate']
HealthRMS  = getRMSData(healthdata,sampleRate)
OuterRMS   = getRMSData(outerdata,sampleRate)
InnerRMS   = getRMSData(innerdata,sampleRate)
BallRMS    = getRMSData(balldata,sampleRate)
CombineRMS = getRMSData(combinedata,sampleRate)

# 获取频域的幅值和频率
healthamp ,healthrate =  getFFTData(healthdata,sampleRate)
outeramp ,outerrate =  getFFTData(outerdata,sampleRate)
inneramp ,innerrate =  getFFTData(innerdata,sampleRate)
ballamp ,ballrate =  getFFTData(balldata,sampleRate)
combineamp ,combinerate =  getFFTData(combinedata,sampleRate)

# 绘制频谱图
plt.subplot(4,4,6)
plotFFTData(healthdata,sampleRate,'health')
plt.subplot(4,4,7)
plotFFTData(outerdata,sampleRate,'outer')
plt.subplot(4,4,8)
plotFFTData(innerdata,sampleRate,'inner')
plt.subplot(4,4,9)
plotFFTData(balldata,sampleRate,'ball')
plt.subplot(4,4,10)
plotFFTData(combinedata,sampleRate,'combine')


avergersize = load_dict['averageSize']
avergernumber = load_dict['averageNumber']

# 绘制各个轴承故障的平均值
plt.subplot(4,4,11)
plotFFTAverage(healthdata,sampleRate,avergersize,avergernumber,'Average health')
plt.subplot(4,4,12)
plotFFTAverage(outerdata,sampleRate,avergersize,avergernumber,'Average outer')
plt.subplot(4,4,13)
plotFFTAverage(innerdata,sampleRate,avergersize,avergernumber,'Average inner')
plt.subplot(4,4,14)
plotFFTAverage(balldata,sampleRate,avergersize,avergernumber,'Average ball')
plt.subplot(4,4,15)
plotFFTAverage(combinedata,sampleRate,avergersize,avergernumber,'Average combine')
plt.show()


sf = load_dict['sf']
Bearing = Inch075MFSBearing()
# ftf, bpfo, bpfi, bsf 是 list的数组
ftf, bpfo, bpfi, bsf = Bearing.Interval_section(sf[0], sf[1])
typerange = [ftf, bpfo, bpfi, bsf]

# 绘制某一区间段的频谱图
plotFFTfromRange(healthdata,sampleRate,'health',typerange)
plotFFTfromRange(outerdata,sampleRate,'outer',typerange)
plotFFTfromRange(innerdata,sampleRate,'inner',typerange)
plotFFTfromRange(balldata,sampleRate,'ball',typerange)
plotFFTfromRange(combinedata,sampleRate,'combine',typerange)


# 绘制区间段平均值的频谱段
titlehealth = ['Average health ftf', 'Average health bpfo','Average health bpfi','Average health bsf']
titleouter = ['Average outer ftf', 'Average outer bpfo','Average outer bpfi','Average outer bsf']
titleinner = ['Average inner ftf', 'Average inner bpfo','Average inner bpfi','Average inner bsf']
titleball = ['Average ball ftf', 'Average ball bpfo','Average ball bpfi','Average ball bsf']
titlecombine = ['Average combine ftf', 'Average combine bpfo','Average combine bpfi','Average combine bsf']

#绘制四种情况下FFT变换的平均值
plotFFTAveragefromRange(healthdata, sampleRate ,avergersize ,avergernumber,typerange, titlehealth)
plotFFTAveragefromRange(outerdata, sampleRate ,avergersize ,avergernumber,typerange, titleouter)
plotFFTAveragefromRange(innerdata, sampleRate ,avergersize ,avergernumber,typerange, titleinner)
plotFFTAveragefromRange(balldata, sampleRate ,avergersize ,avergernumber,typerange, titleball)
plotFFTAveragefromRange(combinedata, sampleRate ,avergersize ,avergernumber,typerange, titlecombine)


