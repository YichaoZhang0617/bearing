#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from scipy.fftpack import fft
import matplotlib.pyplot as plt
import numpy as np

def plotFFTfromRange(data,sampleRate,title,typerange):

    N = len(data)
    x = data
    # 对数据进行傅里叶变换
    y = fft(x, N)
    # 求得傅里叶变换后的振幅
    mag = abs(y)
    # 获取频率序列
    f = []
    for i in range(N):
        ff = i * sampleRate / N
        f.append(ff)

    # 将list转换为ndarray类型
    xx = np.array(f)
    yy = np.array(mag)

    fig = plt.figure()

    # 一、绘制保持架区间段的频谱图
    # 选择区间的起始位置,用数学思维，当y = 4832000时，x的取值范围为[0,10000],要求x取值为[14,15]时，求对应的y
    start = int(typerange[0][0] / (sampleRate / N))
    end = int(typerange[0][1] / (sampleRate / N)) + 1

    x2 = xx[start:end + 1]
    y2 = yy[start:end + 1]
    fig.add_subplot(221)
    plt.plot(x2, y2)
    titlename = title + ' ftf'
    plt.title(titlename)

    # 二、绘制外圈区间段的频谱图
    # 选择区间的起始位置
    start = int(typerange[1][0] / (sampleRate / N))
    end = int(typerange[1][1] / (sampleRate / N)) + 1

    x2 = xx[start:end + 1]
    y2 = yy[start:end + 1]
    fig.add_subplot(222)
    plt.plot(x2, y2)
    titlename = title + ' bpfo'
    plt.title(titlename)

    # 三、绘制内圈区间段的频谱图
    # 选择区间的起始位置
    start = int(typerange[1][0] / (sampleRate / N))
    end = int(typerange[1][1] / (sampleRate / N)) + 1

    x2 = xx[start:end + 1]
    y2 = yy[start:end + 1]
    fig.add_subplot(223)
    plt.plot(x2, y2)
    titlename = title + ' bpfi'
    plt.title(titlename)

    # 四、绘制故障区间段的频谱图
    # 选择区间的起始位置
    start = int(typerange[1][0] / (sampleRate / N))
    end = int(typerange[1][1] / (sampleRate / N)) + 1

    x2 = xx[start:end + 1]
    y2 = yy[start:end + 1]
    fig.add_subplot(224)
    plt.plot(x2, y2)
    titlename = title + ' bsf'
    plt.title(titlename)

    plt.show()
