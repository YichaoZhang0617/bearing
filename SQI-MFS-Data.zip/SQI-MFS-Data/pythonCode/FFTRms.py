#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

# 求傅里叶变换之后整个数据点数的RMS值
import math
from scipy.fftpack import fft
def FFTRms(data):
    N = len(data)
    # 对数据进行傅里叶变换
    y = fft(data, N)
    # 求得傅里叶变换后的振幅
    mag = abs(y)
    # fftcount 表示FFT之后数据平方之和
    fftcount = 0
    for i in range(N):
        square = mag[i] + mag[i]
        fftcount = fftcount + square
    fftrms = math.sqrt(fftcount / N)
    return fftrms