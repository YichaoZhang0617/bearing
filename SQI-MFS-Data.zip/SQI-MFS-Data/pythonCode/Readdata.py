#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

def Readdata(data):
    # 新建新的列表lists
    lists = []
    for line in data:
        a = line.split()
        b = a[1:2]
        lists.append(b)
    data.close()
    '''# 这种方法读取数据较慢
    line = data.readline()  # 以行的形式进行读取文件
    list = []
    while line:
        a = line.split()
        b = a[1:2]  # 这是选取需要读取的位数,只读取第二列
        list.append(b)  # 将其添加在列表之中
        line = data.readline()
    data.close()'''
    # 整个lists是一个list，而且每一个具体元素也是list，参与循环，然后将每个元素的list转换为float类型
    s = []
    for q in lists:
        s.append(float(q[0]))    # 注意这里的 q 是list类型，q[0]为str类型
    rowdata = s

    return rowdata