#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao


# 建立一个interval的类对应配置文件里面的configfile里面的type
# 用来确定四种频谱的区间范围
class Inch075MFSBearing(object):
    def Interval_section(self, Min, Max):

        ftfmin = Min * 0.378
        ftfmax = Max * 0.378

        bpfomin = Min * 3.048
        bpfomax = Max * 3.048

        bpfimin = Min * 4.95
        bpfimax = Max * 4.95

        bsfmin = Min * 1.992
        bsfmax = Max * 1.992

        ftf = [ftfmin, ftfmax]
        bpfo = [bpfomin, bpfomax]
        bpfi = [bpfimin, bpfimax]
        bsf = [bsfmin, bsfmax]

        # print('保持架的频谱范围为' + '[' + str(ftfmin) + ',' + str(ftfmax) + ']')
        # print('外圈故障的频谱范围为' + '[' + str(bpfomin) + ',' + str(bpfomax) + ']')
        # print('内圈故障的频谱范围为' + '[' + str(bpfimin) + ',' + str(bpfimax) + ']')
        # print('滚动体故障的频谱范围为' + '[' + str(bsfmin) + ',' + str(bsfmax) + ']')
        return ftf, bpfo, bpfi, bsf


