#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from scipy.fftpack import fft
import matplotlib.pyplot as plt
import numpy as np
from getFFTData import getFFTData

def plotFFTData(data,sampleRate,title):

    N = len(data)
    yy,xx = getFFTData(data,sampleRate)
    # 取一半区间
    x2 = xx[range(int(N / 2))]
    y2 = yy[range(int(N / 2))]
    plt.plot(x2, y2)
    plt.title(title)



