#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

# 表示将数据进行傅里叶变换后的X轴和Y轴数据 （频域和幅值）

from scipy.fftpack import fft
import numpy as np

def FFTXY(data,sampleRate):
    # 求sf区间段上的幅值的最大值
    x = data
    N = len(x)
    # 对数据进行傅里叶变换
    y = fft(x, N)
    # 求得傅里叶变换后的振幅
    mag = abs(y)
    # 获取频率序列，使得获取的频率序列范围为[0,10000]
    f = []
    for i in range(N):
        ff = i * sampleRate / N
        f.append(ff)
    # 将list转换为ndarray类型
    xx = np.array(f)
    yy = np.array(mag)
    return xx,yy