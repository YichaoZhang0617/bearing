#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from scipy.fftpack import fft
import matplotlib.pyplot as plt
import numpy as np

def plotFFTAverage(data , sampleRate ,averageSize ,avergernumber, titlename):
    # count 表示最后求和后的数组
    count = [0] * averageSize
    # averageSize 指分组的个数
    i = 1
    while i < avergernumber:
        start = (i - 1) * averageSize
        end = start + averageSize
        group = data[start:end]
        # group 表示每一小组的平均数
        N = len(group)

        x = group
        # 对数据进行傅里叶变换
        y = fft(x, N)
        # 求得傅里叶变换后的振幅
        mag = abs(y)
        k = 0
        for j in mag:
            if k < averageSize:
                count[k] = j + count[k]
                k = k + 1
        i = i + 1
    # 其中average表示幅值的平均值
    averger = [x / 5 for x in count]
    # 获取频率序列
    f = []
    for i in range(averageSize):
        ff = i * sampleRate / averageSize
        f.append(ff)

    # 将list转换为ndarray类型
    xx = np.array(f)
    yy = np.array(averger)
    # 取一半区间
    x2 = xx[range(int(N / 2))]
    y2 = yy[range(int(N / 2))]
    plt.plot(x2, y2)
    plt.title(titlename)